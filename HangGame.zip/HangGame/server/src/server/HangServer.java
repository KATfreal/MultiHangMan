package server;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JOptionPane;
import javax.swing.text.BadLocationException;

import java.io.*;

public class HangServer extends Thread									// Server is inherited from the Thread object
{
   private ServerSocket serverSocket;										// Declaration of the socket that the server will
   private Socket server;	
   public static List<String> words;
	public static List<Character> playerguesses= new ArrayList<>();
	public static String word;
	//public static String update = "";
	public static String errors = "";
	public static int errorcount = 0;// run on
	public static int win = 0;
	private static File wordlist = new File("file\\google-10000-english.txt");
	public static int currentclient = 1;
   //public static String messages = "";
   public HangServer(int port) throws IOException
   {
      serverSocket = new ServerSocket(port);								// Instantiates the server socket
      serverSocket.setSoTimeout(0);										// Sets the timeout for the socket. A timeout of 0 establishes
   }																		// an infinite timeout

   public void run()
   {
	  int clientno = 1;
	  	  
      while(true)
      {
         try
         {
            System.out.println("Waiting for client on port " +				// Output informational message that the server is waiting
            serverSocket.getLocalPort() + "...");							// for a client on the specified port
             server = serverSocket.accept();							// Wait for a connection from the client
             
             System.out.println("Just connected to "							// Output informational message that the server is connected
                  + server.getRemoteSocketAddress());						// to the client at the specified IP address
            DataInputStream in =											// Get the data from the client
                  new DataInputStream(server.getInputStream());
            System.out.println(in.readUTF());								// Display the data from the client
            DataOutputStream out =											// Prepare the object for returning data to the client
                 new DataOutputStream(server.getOutputStream());
            out.writeInt(clientno);
            clientno++;
            out.writeUTF("Thank you for connecting to "						// Send the data back to the client
              + server.getLocalSocketAddress() + "\nGoodbye!");

            new Thread(new ClientManager(server)).start();
            //server.close();													// Shut down the server
         }catch(SocketTimeoutException s)
         {
            System.out.println("Socket timed out!");
            break;
         }catch(IOException e)
         {
        	 
            e.printStackTrace();
            break;
         }
      }

     

        
   }
   public static void main(String [] args) throws FileNotFoundException
   {
      //int port = Integer.parseInt(args[0]);          						// Used to permit command prompt invocation
	   
      int port = 6066;														// Establish port 6066 as a hard-coded port override
	   
      try
      {
         Thread t = new HangServer(port);								// Instantiates a server on a separate thread
         t.start();															// Executes the server
      }catch(IOException e)
      {
         e.printStackTrace();
      }
      
     
			
			Scanner scanner = new Scanner(wordlist);
					
			 words = new ArrayList<>();
			while(scanner.hasNext()) 
			{
				words.add(scanner.nextLine());
				
			}
			
			Random rand = new Random();
		    word = words.get(rand.nextInt(words.size()));
			System.out.println(word);
			
		
   }
   
   public static String logic(String word, List<Character> playerguesses) 
	{
		
		String update = "";
		int correctcount = 0;
		for(int i = 0; i < word.length(); i++) 
		{
			if(playerguesses.contains(word.charAt(i))) {
				
				update += String.valueOf(word.charAt(i));
				correctcount++; 
				//GUI.textPane.setText(String.valueOf(word.charAt(i)));
				/*
				 * try { //GUI.doc.insertString(GUI.doc.getLength(),
				 * String.valueOf(word.charAt(i)), null); } catch (BadLocationException e) { //
				 * TODO Auto-generated catch block e.printStackTrace(); }
				 */
			}
			else 
			{
				update += "-";
				/*
				 * errors.add(playerguesses.get(errorcount)); errorcount++;
				 */
				
				//GUI.textPane.setText("-");
				/*
				 * try { //GUI.doc.insertString(GUI.doc.getLength(), "-", null); } catch
				 * (BadLocationException e) { // TODO Auto-generated catch block
				 * e.printStackTrace(); }
				 */
			}
		}
		if(word.length() == correctcount) 
		{
			win= 1;
		}
		
		//displayUniqueCharacters(errors);
		//System.out.println();
		
		 return update;
	}
  
   
}

class Message{
	private static String messages = "";
	 public static String getMessage() { return messages; }
	 
	 public static void setMessage(String tmessage) { messages += tmessage; }
	 
	
	
}

 class ClientManager implements Runnable {
    private Socket clientSocket;
    
    public ClientManager(Socket socket) {
        this.clientSocket = socket;
    }

    public void run() {
    	while(true) {
    		    			
    			try {
    				String status = "";
    				
    				DataInputStream in = new DataInputStream(clientSocket.getInputStream());
    	            //System.out.println(in.readUTF());								// Display the data from the client

    				//System.out.println("1: " + Message.getMessage());
    				//ObjectInputStream listin = new ObjectInputStream(clientSocket.getInputStream());
    				//List<Character> receivedList = (List<Character>) listin.readObject();
    				
					String msg = in.readUTF();
					
					//System.out.println(msg);
					//ObjectOutputStream strout = new ObjectOutputStream(clientSocket.getOutputStream());
    				DataOutputStream out =											// Prepare the object for returning data to the client
    						new DataOutputStream(clientSocket.getOutputStream());
    				//out.writeUTF(Message.getMessage());
    				
    				
					if(!msg.isEmpty()) {
						HangServer.currentclient++;
						if(HangServer.currentclient == 3) {
							
							HangServer.currentclient = 1;
						}
						HangServer.playerguesses.add(msg.charAt(0));
						
						//Message.setMessage(msg + "\n");	
						if(!HangServer.word.contains(msg)) {
	    					HangServer.errors+=String.valueOf(msg.charAt(0));
	    					HangServer.errorcount++;
	    				}
						System.out.println(HangServer.errors);
						
						//out.writeInt(HangServer.errorcount);
	    				
					}else {}
					//out.writeUTF("ERR:" + status);
					status = HangServer.logic(HangServer.word,HangServer.playerguesses);
    				System.out.println(status);
					out.writeUTF( status);
					//out.writeUTF("DIS:" + HangServer.errors);
					out.writeUTF( HangServer.errors);
					out.writeInt(HangServer.currentclient);
					out.writeInt(HangServer.errorcount);
					out.writeInt(HangServer.win);
    				
    				//DataOutputStream wordstatus =											// Prepare the object for returning data to the client
    						//new DataOutputStream(clientSocket.getOutputStream());
    				//wordstatus.writeUTF(Message.getMessage());
    				
    			} catch (IOException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			      //System.out.println("error");								// Display the data from the client
    			      break;
    			}
    			
    			
    	}
    }
}
