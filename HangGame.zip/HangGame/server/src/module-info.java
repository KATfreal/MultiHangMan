module server {
	requires java.desktop;
}