package HangNetwork;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.StyledDocument;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.event.ActionEvent;

public class GUI {

	private JFrame frame;
	public static JTextPane textPane= new JTextPane();
	public static JTextPane textPane_1= new JTextPane();
	public static JTextField textField;
	public static JLabel PoleBottom;
	public static JLabel hilt;
	public static JLabel PoleMiddle;
	public static JLabel top;
	public static JLabel curve;
	public static JLabel rope;
	private static ImageIcon playeri = new ImageIcon("images\\New Project (1).png");
	private static ImageIcon PoleBottomi = new ImageIcon("images\\New Project (2).png");
	private static ImageIcon hilti = new ImageIcon("images\\New Project (3).png");
	private static ImageIcon PoleMiddlei = new ImageIcon("images\\New Project (4).png");
	private static ImageIcon topi = new ImageIcon("images\\New Project (5).png");
	private static ImageIcon curvei = new ImageIcon("images\\New Project (6).png");
	private static ImageIcon ropei = new ImageIcon("images\\New Project (7).png");
	
	private Boolean connected = false;
	public static StyledDocument doc = textPane.getStyledDocument();
	public static JButton btnNewButton;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI window = new GUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 864, 548);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel player = new JLabel("player");
		player.setIcon(playeri);
		player.setBounds(10, 128, 307, 366);
		frame.getContentPane().add(player);
		
		 PoleBottom = new JLabel("polebottom");
		PoleBottom.setIcon(PoleBottomi);
		
		PoleBottom.setBounds(0, 132, 398, 358);
		PoleBottom.setVisible(false);
		frame.getContentPane().add(PoleBottom);
		
		 hilt = new JLabel("New label");
		hilt.setIcon(hilti);
		hilt.setBounds(0, 129, 460, 358);
		hilt.setVisible(false);
		frame.getContentPane().add(hilt);
		
		 PoleMiddle = new JLabel("polemiddle");
		PoleMiddle.setIcon(PoleMiddlei);
		PoleMiddle.setBounds(0, 157, 398, 302);
		PoleMiddle.setVisible(false);
		frame.getContentPane().add(PoleMiddle);
		
		 top = new JLabel("");
		top.setIcon(topi);
		top.setBounds(10, 136, 520, 358);
		top.setVisible(false);
		frame.getContentPane().add(top);
		
		 curve = new JLabel("curve");
		curve.setIcon(curvei);
		curve.setBounds(0, 157, 446, 302);
		curve.setVisible(false);
		frame.getContentPane().add(curve);
		
		 rope = new JLabel("rope");
		rope.setIcon(ropei);
		rope.setBounds(10, 174, 298, 274);
		rope.setVisible(false);
		frame.getContentPane().add(rope);
		
		
		textPane.setBounds(589, 216, 151, 20);
		frame.getContentPane().add(textPane);
		
		textField = new JTextField();
		textField.setBounds(641, 288, 50, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		
		 btnNewButton = new JButton("guess");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//HangClient.stopReceiving();
				HangClient.send(textField.getText());
				//HangClient.startReceiving();
				//HangClient.receive();
				//HangClient.guess(HangClient.words);
				
			}
		});
		btnNewButton.setBounds(622, 319, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("START");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//HangClient.connect();
				//HangClient.startReceiving();
				//HangClient.man();
				connectButtonActionPerformed(e);
			}
		});
		btnNewButton_1.setBounds(372, 11, 89, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		textPane_1 = new JTextPane();
		textPane_1.setBounds(589, 428, 151, 20);
		frame.getContentPane().add(textPane_1);
		
		JLabel lblNewLabel = new JLabel("BAD GUESSES");
		lblNewLabel.setBounds(638, 459, 73, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("WORD");
		lblNewLabel_1.setBounds(645, 177, 46, 14);
		frame.getContentPane().add(lblNewLabel_1);
	}
	
	private void startTimer() {
	    Timer timer = new Timer();
	    TimerTask task = new TimerTask() {
	        public void run() {
	        	HangClient.send("");
	        	HangClient.receive();
	        	
	        	if(HangClient.currentClient == HangClient.Client)
	        	{btnNewButton.setEnabled(true);}
	        	else {btnNewButton.setEnabled(false); }
	            //textPane.setText(client.Messages);
	            //System.out.println("reach?");
	        }
	    };
	    timer.schedule(task, 0, 500);
	}
	
	private void connectButtonActionPerformed(ActionEvent e) {
	    HangClient.connect();
	    connected = true;
	    
	    
	    startTimer();
	}
	
	
	}

