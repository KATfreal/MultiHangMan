package HangNetwork;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JOptionPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;

public class HangClient {

	public static List<String> words;
	public static List<Character> playerguesses= new ArrayList<>();
	public static String word;
	public static ArrayList<Character> errors = new ArrayList<Character>();
	public static int errorcount = 0;
	public static int win = 0;
	private static String serverName = "25.47.97.156";
	private static  int port = 6066;	
	public static  int Client;
	public static  int currentClient;
	  private static Socket client;
	  private String input;
	  public String inputname;
	private static File wordlist = new File("images\\google-10000-english.txt");
	  private static Thread receiveThread;
	public static boolean errormade ;
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		
		man();
	}
	
	public static void man() throws FileNotFoundException {
		
		Scanner scanner = new Scanner(wordlist);
				
		 words = new ArrayList<>();
		while(scanner.hasNext()) 
		{
			words.add(scanner.nextLine());
			
		}
		
		Random rand = new Random();
	    word = words.get(rand.nextInt(words.size()));
		System.out.println(word);
		
	}

	public static void guess(List<String> words) {
		
		GUI.textPane.setText("");
		GUI.textPane_1.setText("");
		
		//List<Character> playerguesses = new ArrayList<>();
		
		//logic(word,playerguesses);
		
		
		//System.out.println("make a guess");
		String LetterGuess = GUI.textField.getText();
		//in.nextLine();
		playerguesses.add(LetterGuess.charAt(0));
		logic(word,playerguesses);
		
		if(!word.contains(LetterGuess)) {
			errors.add(LetterGuess.charAt(0));
			errorcount++;
		}
		displayUniqueCharacters(errors);
	}
	
	public static void logic(String word, List<Character> playerguesses) 
	{
		
		
		for(int i = 0; i < word.length(); i++) 
		{
			if(playerguesses.contains(word.charAt(i))) {
				
				//GUI.textPane.setText(String.valueOf(word.charAt(i)));
				try {
					GUI.doc.insertString(GUI.doc.getLength(), String.valueOf(word.charAt(i)), null);
				} catch (BadLocationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else 
			{
				/*
				 * errors.add(playerguesses.get(errorcount)); errorcount++;
				 */
				
				//GUI.textPane.setText("-");
				try {
					GUI.doc.insertString(GUI.doc.getLength(), "-", null);
				} catch (BadLocationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		//displayUniqueCharacters(errors);
		//System.out.println();
	}
	
	 public static void displayUniqueCharacters( ArrayList<Character> array) {
	        
	        HashSet<Character> uniqueChars = new HashSet<>();
	        for (char c : array) {
	            if (!uniqueChars.contains(c)) {
	                uniqueChars.add(c);
	                try {
	                    Document doc = GUI.textPane_1.getDocument();
	                    doc.insertString(doc.getLength(), String.valueOf(c), null);
	                } catch (BadLocationException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	    }
	 public static void send(String message) {
		   
		   OutputStream outToServer;
		try {
			//String LetterGuess = GUI.textField.getText();
		
			outToServer = client.getOutputStream();
			//ObjectOutputStream out = new ObjectOutputStream(client.getOutputStream());
			DataOutputStream strout =
					new DataOutputStream(outToServer);
			
			//out.writeObject(playerguesses);
			strout.writeUTF(message);
			//out.flush();
			/*
			 * if(!message.isEmpty()) out.writeUTF(String.valueOf(LetterGuess.charAt(0)));
			 * else out.writeUTF(message);
			 */

			/*
			 * InputStream inFromServer = client.getInputStream(); DataInputStream in = new
			 * DataInputStream(inFromServer); Messages = in.readUTF();
			 */
			//client.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
		 public static void receive() 
		   {
			  
			   InputStream inFromServer;
			try {
				inFromServer = client.getInputStream();
				DataInputStream in =
						new DataInputStream(inFromServer);
				//ObjectInputStream listin = new ObjectInputStream(client.getInputStream());
				
				String receivedMessage = in.readUTF();
				String erro = in.readUTF();
				currentClient = in.readInt();
				errorcount = in.readInt();
				win = in.readInt();
				GUI.textPane.setText(receivedMessage);
				 GUI.textPane_1.setText(erro);
				setimage();
				if (receivedMessage.startsWith("DIS:")||erro.startsWith("DIS:")) {
				    // Handle regular message
				    String message = receivedMessage.substring(4);
				    
				}  if (receivedMessage.startsWith("ERR:")||erro.startsWith("ERR:")) {
				    // Handle error message
				    String errorMessage = erro.substring(4);
				   
				} 
				//playerguesses = (List<Character>) listin.readObject();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
		}
	 
	 public static void connect() {
		 //String serverName = args[0];								// Used for command line parameter
		      //int port = Integer.parseInt(args[1]);						// Used for command line parameter
		      
		    				// Establish the local machine as the
		      																// server
		     										// Hard-code port for connection
		      try
		      {
		    	  
		         System.out.println("Connecting to " + serverName
		                             + " on port " + port);
		          client = new Socket(serverName, port);
		         System.out.println("Just connected to "
		                      + client.getRemoteSocketAddress());
		         OutputStream outToServer = client.getOutputStream();
		         DataOutputStream out =
		                       new DataOutputStream(outToServer);

		         out.writeUTF("Hello from "
		                      + client.getLocalSocketAddress());
		         InputStream inFromServer = client.getInputStream();
		         DataInputStream in =
		                        new DataInputStream(inFromServer);
		         Client = in.readInt();
		         System.out.println("Server says " + in.readUTF());
		         //client.close();
		      }catch(IOException e)
		      {
		         e.printStackTrace();
		      }
	   }
	 public static void startReceiving() {
		    receiveThread = new Thread(() -> {
		        while (true) {
		            receive();
		        }
		    });
		    receiveThread.start();
		}

		public static void setimage() throws IOException {
		   if(errorcount>= 1) 
		   {GUI.PoleBottom.setVisible(true);}
		   if(errorcount>= 2) 
		   {GUI.hilt.setVisible(true);}
		   if(errorcount>= 3) 
		   {GUI.PoleMiddle.setVisible(true);}
		   if(errorcount>= 4) 
		   {GUI.top.setVisible(true);}
		   if(errorcount>= 5) 
		   {GUI.curve.setVisible(true);}
		   if(errorcount>= 6) 
		   {GUI.rope.setVisible(true);}
		   
		   if (errorcount >= 7) 
		   {
			   JOptionPane.showMessageDialog(null, "you have unfortunately lost the game and killed the man");
			   client.close();
			   
		   }
		   
		   if (win == 1) 
		   {
			   JOptionPane.showMessageDialog(null, "YOU WON");
			   client.close();
			   
		   }
		}
		
		
	   
}
 