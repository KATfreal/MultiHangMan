module HangNetwork {
	requires java.desktop;
}